﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_ticket_system.Controller
{
   public class Moviecontroller
    {

        public string Name { get; set; }
        public string Catagory { get; set; }
        public string Price { get; set; }
        public string Time { get; set; }
        public string Biyer { get; set; }
        public string Seat { get; set; }
        public string sl { get; set; }
        public string status { get; set; }

    }
}
